document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const summarizeBtn = document.getElementById('summarizeBtn');
    const uploadSection = document.getElementById('uploadSection');
    const resultSection = document.getElementById('resultSection');
    const loadingState = document.getElementById('loadingState');
    const summaryContent = document.getElementById('summaryContent');
    const summaryText = document.getElementById('summaryText');
    const resetBtn = document.getElementById('resetBtn');

    let currentFile = null;

    // File Drag and Drop Handlers
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length) {
            handleFile(e.target.files[0]);
        }
    });

    // Handle the uploaded text file or zip file
    function handleFile(file) {
        if (file.type !== 'text/plain' && file.type !== 'application/zip' && file.type !== 'application/x-zip-compressed' && !file.name.endsWith('.zip')) {
            alert('Please upload a .txt or .zip file');
            return;
        }

        currentFile = file;
        dropZone.querySelector('h3').textContent = file.name;
        dropZone.querySelector('p').textContent = 'File ready to process';
        summarizeBtn.disabled = false;
    }

    // Call Backend API
    summarizeBtn.addEventListener('click', async () => {
        if (!currentFile) return;

        // Transition UI
        uploadSection.classList.add('hidden');
        resultSection.classList.remove('hidden');
        loadingState.classList.remove('hidden');
        summaryContent.classList.add('hidden');

        const formData = new FormData();
        formData.append('file', currentFile);

        try {
            const response = await fetch('/api/summarize', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Server Error');
            }

            // Render markdown using the marked library imported in index.html
            summaryText.innerHTML = marked.parse(data.summary);
            
            loadingState.classList.add('hidden');
            summaryContent.classList.remove('hidden');

        } catch (error) {
            alert('Error: ' + error.message);
            resetUI();
        }
    });

    // Reset Flow
    resetBtn.addEventListener('click', () => {
        resetUI();
    });

    function resetUI() {
        currentFile = null;
        fileInput.value = '';
        dropZone.querySelector('h3').textContent = 'Drag & Drop your chat.txt or .zip';
        dropZone.querySelector('p').textContent = 'or click to browse';
        summarizeBtn.disabled = true;
        
        resultSection.classList.add('hidden');
        uploadSection.classList.remove('hidden');
        summaryText.innerHTML = '';
    }
});
