import os
import re
import tempfile
import zipfile
import shutil
import mimetypes
from functools import wraps
from flask import Flask, request, jsonify, render_template, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import google.generativeai as genai
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
# Security setup
app.secret_key = os.getenv('APP_SECRET_KEY', 'default_secret_key_if_env_missing')

# Configure SQLite Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Load API Key and Admin Credentials from environment variables
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("ADMIN_PASS", "Admin@007")

# Database Models
class Summary(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255))
    content = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Create database tables if they don't exist
with app.app_context():
    db.create_all()

# Authentication Decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Helper function to parse chat
def parse_chat(text):
    lines = text.split('\n')
    parsed_messages = []
    
    # Regex handles Android and iOS WhatsApp exports
    pattern = re.compile(
        r'\[?(?P<date>\d{1,2}/\d{1,2}/\d{2,4}),?\s(?P<time>\d{1,2}:\d{2}(?::\d{2})?(?:\s?[aApP][mM])?)\]?\s?-?\s?(?P<sender>[^:]+):\s?(?P<message>.*)'
    )
    
    for line in lines:
        match = pattern.match(line)
        if match:
            date = match.group('date')
            time = match.group('time')
            sender = match.group('sender')
            message = match.group('message')
            parsed_messages.append(f"[{date} {time}] {sender}: {message}")
            
    return '\n'.join(parsed_messages)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == ADMIN_USER and password == ADMIN_PASS:
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/api/summarize', methods=['POST'])
@login_required
def summarize():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
    
    prompt_contents = []
    uploaded_gemini_files = []
    
    try:
        # Create a temporary directory to process files
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, file.filename)
            file.save(file_path)
            
            chat_text = ""
            
            if file.filename.endswith('.zip'):
                # Extract ZIP
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                
                # Find the text file and media files
                for root, _, files in os.walk(temp_dir):
                    for f in files:
                        full_path = os.path.join(root, f)
                        if f.endswith('.txt'):
                            with open(full_path, 'r', encoding='utf-8') as txt_file:
                                chat_text = txt_file.read()
                        elif f != file.filename: # It's a media file (ignore the zip itself)
                            mime_type, _ = mimetypes.guess_type(full_path)
                            if mime_type and (mime_type.startswith('image/') or mime_type.startswith('audio/') or mime_type.startswith('video/')):
                                try:
                                    gemini_file = genai.upload_file(full_path, mime_type=mime_type)
                                    uploaded_gemini_files.append(gemini_file)
                                except Exception as e:
                                    print(f"Warning: Failed to upload media {f}: {e}")
            else:
                # It's just a text file
                with open(file_path, 'r', encoding='utf-8') as txt_file:
                    chat_text = txt_file.read()
                    
            formatted_chat = parse_chat(chat_text)
            
            if not formatted_chat:
                return jsonify({'error': 'Could not parse any messages. Ensure it is a valid WhatsApp .txt or .zip export.'}), 400
                
            prompt_text = f"""
            Please provide a comprehensive summary of the following WhatsApp group chat. 
            Highlight the main topics discussed, any key decisions made, and any action items assigned to specific people.
            If media files (images, audio, video) are provided, please incorporate their contents into the context of the summary where relevant.
            
            Chat Log:
            {formatted_chat}
            """
            
            prompt_contents.append(prompt_text)
            prompt_contents.extend(uploaded_gemini_files)
            
            response = model.generate_content(prompt_contents)
            summary_text = response.text
            
            # Save summary to database
            new_summary = Summary(filename=file.filename, content=summary_text)
            db.session.add(new_summary)
            db.session.commit()
            
            # Clean up Gemini uploaded files to save quota
            for g_file in uploaded_gemini_files:
                try:
                    genai.delete_file(g_file.name)
                except:
                    pass
            
            return jsonify({'summary': summary_text})
            
    except Exception as e:
        for g_file in uploaded_gemini_files:
            try:
                genai.delete_file(g_file.name)
            except:
                pass
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
